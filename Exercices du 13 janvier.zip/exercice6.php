<?php
/*
    Exercice 6:
     Initialiser une variable un mois et une  annee qui sont 
     des  entiers puis affiche determine le nombre de jours 
     de ce mois dans cette annee
     Exemple :
     mois=2 annee:2020  nbreJours=29
     mois=2 annee:2021  nbreJours=28
     mois=12 annee:2021  nbreJours=31
     mois=4 annee:2021  nbreJours=30
  */
  $nbreJours = null;
  $mois = rand(1,12);
  $annee = rand(0,9999);

  if ($mois = 1||3||5||7||8||10||12) {
    echo "mois=$mois annee:$annee nbreJours=31";
  }

  if ($mois = 4||6||9||11) {
    echo "mois=$mois annee:$annee nbreJours=30";
  }

  if ($mois = 2 && $annee%4 == 0) {
    echo "mois=$mois annee:$annee nbreJours=29";
  } elseif ($mois = 2 && $date%4 != 0) {
    echo "mois=$mois annee:$annee nbreJours=28";
  }

?>