<?php
  /*
    Exercice 3:
     Initialiser trois variables  puis les ranger
      dans l'ordre decroissant
  */

    $numbers = array(4, 6, 2);
    rsort($numbers); tri numérique décroissant ; sort($numbers); tri numérique croissant


        $arrlength = count($numbers);
        for($x = 0; $x < $arrlength; $x++) {
        echo $numbers[$x];
        echo "<br>";
        }

?>