<?php
/*
    Exercice 5:
     Initialiser une variable une annee  entier
      puis affiche si cette année est bisextile ou pas 
  */

    $date=rand(0,9999);
    if ($date%4 == 0) {
        echo "$date est une année bisextile";
    }
?>