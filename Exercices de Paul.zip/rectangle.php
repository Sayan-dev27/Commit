<?php
    $longueur = 10;
    $largeur = 6;

    $perimetre = ($longueur + $largeur) * 2;
    echo $perimetre;

    $demiperimetre = $longueur + $largeur;
    echo $demiperimetre;

    $surface = $longueur * $largeur;
    echo $surface;

    $diagonale = sqrt(($longueur*$longueur) + ($largeur*$largeur));
    echo $diagonale;
?>