<?php
    $rayon = 10;

    $diametre = $rayon * 2;
    echo $diametre;

    $perimetre = $rayon*360;
    echo $perimetre;

    $demiperimetre = $perimetre/2;
    echo $demiperimetre;

    $surface = $rayon*$rayon;
    echo $surface;
?>