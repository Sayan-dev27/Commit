<?php
    $cote = 8;

    $perimetre = $cote * 4;
    echo $perimetre;

    $demiperimetre = $perimetre % 2;
    echo $demiperimetre;

    $surface = $cote * $cote;
    echo $surface;

    $diagonale = $cote * sqrt(2);
    echo $diagonale;
?>